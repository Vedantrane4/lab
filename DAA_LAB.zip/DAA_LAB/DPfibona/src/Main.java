class FibonacciDP {

    // Function to calculate the nth Fibonacci number using DP (Tabulation)
    public static int fibonacci(int n) {
        if (n <= 1) {
            return n; // Base cases: Fib(0) = 0, Fib(1) = 1
        }

        // Array to store Fibonacci numbers
        int[] dp = new int[n + 1];
        dp[0] = 0; // Fib(0)
        dp[1] = 1; // Fib(1)

        // Build the Fibonacci sequence iteratively
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }

        return dp[n]; // Return the nth Fibonacci number
    }

    public static void main(String[] args) {
        int n = 10; // Find the 10th Fibonacci number
        System.out.println("The " + n + "th Fibonacci number is: " + fibonacci(n));
    }
}

/*public class BinomialCoefficient {
    // Function to calculate nCk using dynamic programming
    public static int binomialCoefficient(int n, int k) {
        // Table to store values of binomial coefficients
        int[][] dp = new int[n + 1][k + 1];

        // Fill the table bottom-up
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= Math.min(i, k); j++) {
                // Base cases: C(i, 0) = C(i, i) = 1
                if (j == 0 || j == i) {
                    dp[i][j] = 1;
                } else {
                    // Recursive formula: C(i, j) = C(i-1, j-1) + C(i-1, j)
                    dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j];
                }
            }
        }

        return dp[n][k];
    }

    public static void main(String[] args) {
        int n = 5; // Example value of n
        int k = 2; // Example value of k

        System.out.println("Binomial Coefficient (" + n + "C" + k + ") = " + binomialCoefficient(n, k));
    }
}
*/
class Knapsack {

    // Function to solve the 0-1 Knapsack problem using dynamic programming
    public static int knapSack(int W, int[] weight, int[] profit, int N) {
        // Create a 2D dp array to store the maximum profit for each subproblem
        int[][] dp = new int[N + 1][W + 1];

        // Fill the dp table
        for (int i = 0; i <= N; i++) {
            for (int w = 0; w <= W; w++) {
                if (i == 0 || w == 0) {
                    dp[i][w] = 0;  // Base case: no items or no capacity
                } else if (weight[i - 1] <= w) {
                    // Item can be included, take the maximum of including or excluding it
                    dp[i][w] = Math.max(dp[i - 1][w], dp[i - 1][w - weight[i - 1]] + profit[i - 1]);
                } else {
                    // Item cannot be included
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }

        // The bottom-right corner of the dp table holds the maximum profit
        return dp[N][W];
    }

    public static void main(String[] args) {
        int N = 3;  // Number of items
        int W = 4;  // Maximum weight of the knapsack
        int[] profit = {1, 2, 3};  // Profits of the items
        int[] weight = {4, 5, 1};  // Weights of the items

        // Call the knapsack function to find the maximum profit
        int result = knapSack(W, weight, profit, N);

        // Output the result
        System.out.println("Maximum profit: " + result);
    }
}

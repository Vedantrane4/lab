class MatrixChainMultiplication {

    // Function to compute the minimum number of scalar multiplications needed
    public static int matrixChainOrder(int[] p, int n) {
        // Create a table to store results of subproblems
        int[][] m = new int[n][n];

        // m[i][i] is 0 because a single matrix has no cost to multiply
        for (int i = 1; i < n; i++) {
            m[i][i] = 0;
        }

        // l is the chain length
        for (int length = 2; length < n; length++) {
            for (int i = 1; i < n - length + 1; i++) {
                int j = i + length - 1;
                m[i][j] = Integer.MAX_VALUE; // Initialize to a large value

                // Try different split points k
                for (int k = i; k < j; k++) {
                    int q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j];
                    if (q < m[i][j]) {
                        m[i][j] = q; // Store the minimum cost
                    }
                }
            }
        }

        return m[1][n - 1];
    }

    public static void main(String[] args) {
        // Matrix dimensions (10x100), (100x5), (5x500)
        int[] p = {10, 100, 5, 500}; // p[i-1] x p[i] are the dimensions of A_i

        int n = p.length;

        // Call matrixChainOrder function to get the minimum cost
        int result = matrixChainOrder(p, n);

        System.out.println("Minimum cost of multiplication is: " + result);
    }
}

 class RodCutting {

    // Function to find the maximum profit from rod cutting
    public static int rodCutting(int[] price, int n) {
        // dp[i] will store the maximum profit for rod of length i
        int[] dp = new int[n + 1];

        // Fill the dp array
        for (int i = 1; i <= n; i++) {
            int maxProfit = Integer.MIN_VALUE;
            // Try all possible cuts
            for (int j = 1; j <= i; j++) {
                maxProfit = Math.max(maxProfit, price[j - 1] + dp[i - j]);
            }
            dp[i] = maxProfit;
        }

        return dp[n]; // The maximum profit for rod of length n
    }

    public static void main(String[] args) {
        int[] price = {1, 5, 8, 9, 10, 17, 17, 20};
        int n = 4; // Rod length

        // Call the rodCutting function
        int maxProfit = rodCutting(price, n);

        System.out.println("Maximum profit for rod of length " + n + " is " + maxProfit);
    }
}

class MaximumSumSubsequence {

    // Function to find the maximum sum of subsequence with no adjacent elements
    public static int maxSumSubsequence(int[] arr) {
        int n = arr.length;

        if (n == 0) return 0; // If the array is empty, return 0
        if (n == 1) return arr[0]; // If the array has only one element, return that element

        // Initialize dp array
        int[] dp = new int[n];

        // Base cases
        dp[0] = arr[0];  // Only one element to choose from
        dp[1] = Math.max(arr[0], arr[1]);  // Choose the maximum of the first two elements

        // Fill the dp array using the recurrence relation
        for (int i = 2; i < n; i++) {
            dp[i] = Math.max(dp[i-1], arr[i] + dp[i-2]);
        }

        // The answer will be stored in dp[n-1]
        return dp[n-1];
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 9, 4, 5, 0, 4, 11, 6};

        // Call the function to find the maximum sum of the subsequence
        int result = maxSumSubsequence(arr);

        System.out.println("The maximum sum of the subsequence with no adjacent elements is: " + result);
    }
}

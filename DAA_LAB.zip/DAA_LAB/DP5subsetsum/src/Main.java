import java.util.ArrayList;
import java.util.List;

class SubsetSum {

    // Function to check if there's a subset with the given sum k
    public static boolean isSubsetSum(int[] arr, int n, int k, List<Integer> subset) {
        // Create a DP array of size k + 1 and initialize it with false
        boolean[] dp = new boolean[k + 1];

        // A sum of 0 is always possible (with an empty subset)
        dp[0] = true;

        // Fill the DP array
        for (int i = 0; i < n; i++) {
            // Traverse backward to avoid using the same item twice
            for (int j = k; j >= arr[i]; j--) {
                dp[j] = dp[j] || dp[j - arr[i]];
            }
        }

        // If dp[k] is true, there exists a subset that sums to k
        if (dp[k]) {
            // Backtrack to find the subset
            int sum = k;
            for (int i = n - 1; i >= 0; i--) {
                if (sum >= arr[i] && dp[sum - arr[i]]) {
                    subset.add(arr[i]);
                    sum -= arr[i];
                }
            }
            return true;
        }

        return false;
    }

    public static void main(String[] args) {
        int[] arr = {7, 3, 2, 5, 8};
        int k = 14;
        List<Integer> subset = new ArrayList<>();

        // Call the function to check if a subset with sum k exists
        if (isSubsetSum(arr, arr.length, k, subset)) {
            System.out.println("Subset with the given sum exists");
            System.out.print("Subset { ");
            for (int num : subset) {
                System.out.print(num + " ");
            }
            System.out.println("} sums to " + k);
        } else {
            System.out.println("No subset with the given sum exists");
        }
    }
}

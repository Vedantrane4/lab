 class OptimalBST {

    // Function to find the optimal cost to construct a binary search tree
    public static int optimalCost(int[] keys) {
        int n = keys.length;

        // cost[i][j] will store the minimum cost of BST with keys in the range [i, j]
        int[][] cost = new int[n][n];

        // sum[i][j] stores the sum of keys in the range [i, j]
        int[][] sum = new int[n][n];

        // Fill the sum matrix
        for (int i = 0; i < n; i++) {
            sum[i][i] = keys[i];
            for (int j = i + 1; j < n; j++) {
                sum[i][j] = sum[i][j - 1] + keys[j];
            }
        }

        // Fill the cost matrix
        for (int length = 1; length <= n; length++) {
            for (int i = 0; i <= n - length; i++) {
                int j = i + length - 1;
                if (length == 1) {
                    cost[i][j] = keys[i];
                } else {
                    cost[i][j] = Integer.MAX_VALUE;
                    for (int k = i; k <= j; k++) {
                        int leftCost = (k > i) ? cost[i][k - 1] : 0;
                        int rightCost = (k < j) ? cost[k + 1][j] : 0;
                        cost[i][j] = Math.min(cost[i][j], leftCost + rightCost + sum[i][j]);
                    }
                }
            }
        }

        // The minimum cost to construct the BST from all keys is cost[0][n-1]
        return cost[0][n - 1];
    }

    public static void main(String[] args) {
        int[] keys = {10, 20, 30, 40, 50, 60, 70};

        // Call the function to find the optimal BST cost
        int minCost = optimalCost(keys);

        System.out.println("The minimum cost to construct the binary search tree is: " + minCost);
    }
}

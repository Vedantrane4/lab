 class LongestCommonPrefix {

    // Helper function to find the common prefix between two strings
    public static String commonPrefix(String str1, String str2) {
        int minLength = Math.min(str1.length(), str2.length());
        int i = 0;
        while (i < minLength && str1.charAt(i) == str2.charAt(i)) {
            i++;
        }
        return str1.substring(0, i);
    }

    // Divide and Conquer function to find LCP of an array of strings
    public static String longestCommonPrefix(String[] strs, int left, int right) {
        // Base case: if there is only one string
        if (left == right) {
            return strs[left];
        } else {
            // Find the mid point
            int mid = left + (right - left) / 2;

            // Recursively find the LCP of the left and right halves
            String leftLCP = longestCommonPrefix(strs, left, mid);
            String rightLCP = longestCommonPrefix(strs, mid + 1, right);

            // Find the common prefix of the two LCPs
            return commonPrefix(leftLCP, rightLCP);
        }
    }

    public static void main(String[] args) {
        String[] strs = {"technique", "technician", "technology", "technical"};

        if (strs == null || strs.length == 0) {
            System.out.println("No strings provided");
            return;
        }

        // Call the divide and conquer function
        String result = longestCommonPrefix(strs, 0, strs.length - 1);

        System.out.println("The longest common prefix is: " + result);
    }
}
